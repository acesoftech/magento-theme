define(['jquery'], function ($) {
    'use strict';
    return function () {
        console.log('Navigation menu JS loaded');
    };
});
