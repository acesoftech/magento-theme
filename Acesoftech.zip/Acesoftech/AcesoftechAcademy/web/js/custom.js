// Acesoftech Academy Custom JavaScript
require(['jquery'], function($) {
    'use strict';

    $(document).ready(function() {
        // Custom JavaScript for your theme
        console.log('Acesoftech Academy Theme loaded');

        // Example: Smooth scroll for anchor links
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            var target = $(this.getAttribute('href'));
            if (target.length) {
                $('html, body').stop().animate({
                    scrollTop: target.offset().top
                }, 1000);
            }
        });
    });
});
