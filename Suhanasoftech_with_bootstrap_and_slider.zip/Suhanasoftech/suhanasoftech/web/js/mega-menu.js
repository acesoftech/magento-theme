define(['jquery','js/bootstrap'], function ($) {
    'use strict';

    return function () {

        console.log('Mega Menu Inited ✅');

        /* ===============================
           LEVEL 0
        ===============================*/
        $('#mainMenu > li.level0').each(function () {

            let $li = $(this);
            let $a  = $li.children('a');
            let $ul = $li.children('ul');

            if ($ul.length) {

                $li.addClass('nav-item dropdown');

                $a.addClass('nav-link dropdown-toggle')
                  .attr({
                      'data-bs-toggle': 'dropdown',
                      'role': 'button',
                      'aria-expanded': 'false'
                  });

                $ul.addClass('dropdown-menu');

            } else {

                $li.addClass('nav-item');
                $a.addClass('nav-link');

            }

        });

        /* ===============================
           LEVEL 1 + LEVEL 2
        ===============================*/
        $('#mainMenu ul.dropdown-menu li').each(function () {

            let $li = $(this);
            let $a  = $li.children('a');
            let $ul = $li.children('ul');

            if ($ul.length) {

                $li.addClass('dropdown-submenu');

                $a.addClass('dropdown-item dropdown-toggle');

                $ul.addClass('dropdown-menu');

            } else {

                $a.addClass('dropdown-item');

            }

        });

    };
});
