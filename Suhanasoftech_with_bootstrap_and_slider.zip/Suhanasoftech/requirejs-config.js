var config = {
    paths: {
        'bootstraps': 'js/bootstrap'
    },
    shim: {
        'bootstraps': {
            deps: ['jquery']
        }
    }
};
